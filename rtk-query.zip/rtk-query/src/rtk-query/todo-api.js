import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'

export const todoApi = createApi({
    reducerPath: "todoApi",
    tagTypes: ["Todos"],
    baseQuery: fetchBaseQuery({
        baseUrl: 'http://127.0.0.1:8000',
        prepareHeaders: (headers, { getState }) => {
            const token = getState().auth.token;
            if (token) {
                headers.set('authorization', `Bearer ${token}`)
            }

            return headers;
        },
    }),
    endpoints: (build) => ({
        getTodos: build.query({
            query: () => 'todo',
            providesTags: (result) =>
                result
                    ? [
                        ...result.map(({ id }) => ({ type: 'Todos', id })),
                        { type: 'Todos', id: 'LIST' },
                    ]
                    : [{ type: 'Todos', id: 'LIST' }],
        }),
        addTodo: build.mutation({
            query: (body) => ({
                url: 'todo',
                method: 'POST',
                body,
            }),
            invalidatesTags: ['Todos'],
        }),
        delTodo: build.mutation({
            query: (id) => ({
                url: `todo/${id}`,
                method: 'DELETE'
            }),
            invalidatesTags: ['Todos'],
        }),
        selectTodo: build.mutation({
            query: (item) =>({
                url: `todo/${item.id}`,
                method: 'PUT',
                body: item,
            }),
            invalidatesTags: ['Todos'],
        })
    }),
});

export const { useGetTodosQuery, useAddTodoMutation, useDelTodoMutation, useSelectTodoMutation} = todoApi;