import { configureStore } from "@reduxjs/toolkit";
import { todoApi } from "./todo-api";
import { authReducer } from "./auth-reducer";

export const store = configureStore({
    reducer: {
        [todoApi.reducerPath]: todoApi.reducer,
        auth: authReducer,
    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(todoApi.middleware),
})