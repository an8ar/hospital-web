import { createSlice } from '@reduxjs/toolkit'

const authSlice = createSlice({
    name: 'auth',
    initialState: {
        auth: '',
        token: ''
    },
    reducers: {
        logoutAction(state, action){
            state.auth = '';
            state.token = '';
        },
        loginAction(state, action){
            state.auth = action.payload.nickname;
            state.token = action.payload.token;
        },
        registerAction(state, action){
            state.auth = action.payload.nickname;
            state.token = action.payload.token;
        },
    },
})

export const {logoutAction,loginAction, registerAction} = authSlice.actions;

export const authReducer = authSlice.reducer;