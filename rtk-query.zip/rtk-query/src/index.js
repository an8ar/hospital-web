import React from 'react';
import ReactDOM from 'react-dom/client';
import { SnackbarProvider } from 'notistack';
import App from './App';

import { Provider } from 'react-redux';
import {store} from './rtk-query/store';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <SnackbarProvider>
      <Provider store={store}> 
        <App />
      </Provider>
    </SnackbarProvider>
  </React.StrictMode>
);