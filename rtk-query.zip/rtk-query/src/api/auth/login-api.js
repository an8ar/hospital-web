import axios from 'axios';

export async function login(data) {
    try {
        const responce = await axios.post('http://127.0.0.1:8000/user/login', {
            nickname: data.nickname,
            password: data.password
            }
        )
        return responce.data.token;
    }catch (error) {
        console.log("Error in a login_api", error);
    }
}





