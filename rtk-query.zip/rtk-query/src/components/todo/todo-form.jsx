import React from 'react';
import { useState } from 'react';
import { TextField, Button } from '@mui/material';
import Divider from '@mui/material/Divider';
import Stack from '@mui/material/Stack';
import { useAddTodoMutation } from '../../rtk-query/todo-api';

const TodoForm = () => {

    const [value, setvalue] = useState('');
    const [addTask] = useAddTodoMutation();
    async function addTodo() {
        if (value !== undefined) {
            await addTask({title:value});
        }
        setvalue('');
    }
    return (
        <Stack spacing={3} direction="row" divider={<Divider orientation="vertical" flexItem />} >
            <TextField id="outlined-basic" label="Enter new Task" variant="outlined" value={value} onChange={((e) => setvalue(e.target.value))} />
            <Button variant="contained" onClick={addTodo} size="large" className='buttonAdd'>ADD TASK</Button>
        </Stack>
    );
}

export default TodoForm;