import React from 'react'
import TodoForm from './todo-form';
import Tasks from './tasks';
import Stack from '@mui/material/Stack';
import Container from '@mui/material/Container';

function Todo() {
  return (
    <Container >
      <Stack direction="column"
        justifyContent="center"
        alignItems="center"
        spacing={2}
        margin={5}>
        <TodoForm />
        <Tasks className="listOfTodos"/>
      </Stack>
    </Container>
  );
};

export default Todo;