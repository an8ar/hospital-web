import React from "react";
import DeleteIcon from '@mui/icons-material/Delete';
import { Button } from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Checkbox from '@mui/material/Checkbox';
import IconButton from '@mui/material/IconButton';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import { useDelTodoMutation, useGetTodosQuery, useSelectTodoMutation } from '../../rtk-query/todo-api'


function Tasks() {
    const { data = [], isLoading } = useGetTodosQuery();
    const [delTodo] = useDelTodoMutation();
    const [selectTodo] = useSelectTodoMutation();
    if (data.length == 0) {
        return (
            <Alert severity="info">There is no tasks!</Alert>
        )
    }
    if (isLoading) {
        return <h1>Loading...</h1>;
    }
    const handleDelete = async (id) => {
        await delTodo(id);
    }
    function checkStyle(task){
        if (task.completed){
            return "line-through"
        }else{
            return "none"
        }
    };
    async function handleToggle(task, e) {
        const copy = { ...task };
        copy.completed = !copy.completed;
        await selectTodo(copy);
    }
    function deleteSelectedTodos() {
        const copy = [...data];
        copy.map(async item => {
            if (item.completed) {
                await delTodo(item.id);
            }
        })
    }
    async function deleteAll() {
        const copy = [...data];
        copy.map(async item => {
            await delTodo(item.id);
        })
    }
    return <Stack >
        <List sx={{ width: '100%', maxWidth: 400 }}>
            {data.map(task =>
                <ListItem
                    key={task.id}
                    divider
                    secondaryAction={
                        <IconButton edge="end" aria-label="comments" onClick={() => handleDelete(task.id)}>
                            <DeleteIcon />
                        </IconButton>
                    }
                    disablePadding
                >
                    <ListItemButton>
                        <ListItemIcon>
                            <Checkbox type="checkbox" className="t" onChange={(e) => handleToggle(task, e)
                            } />
                        </ListItemIcon>
                        <ListItemText sx={{
                            overflow: "scroll",
                            textDecoration: `${checkStyle(task)}`
                        }} >{task.title}</ListItemText>
                    </ListItemButton>
                </ListItem>

            )}
        </List>
        <Stack direction="row" spacing={2}>
            <Button variant="contained" onClick={deleteSelectedTodos}>Delete Selected</Button>
            <Button variant="contained" onClick={deleteAll}>Delete All</Button>
        </Stack>
    </Stack>
}
export default Tasks;