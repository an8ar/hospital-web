import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";
import { useSnackbar } from 'notistack';
import { useDispatch, useSelector } from 'react-redux';
import { logoutAction } from '../../rtk-query/auth-reducer';


export default function NavBarApp() {
  const dispatch = useDispatch();
  const username = useSelector((state) => state.auth.auth);
  const token = useSelector((state)=>state.auth.token)
  const navigate = useNavigate();
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();

  function navigating() {
    if (token=='') {
      enqueueSnackbar("You are already logged out!", { variant: 'warning' });
    }
    dispatch(logoutAction());
    navigate('/login');
  }


  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Todo List of {username}
          </Typography>
          <Button color="inherit" onClick={navigating
          }>Logout</Button>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
