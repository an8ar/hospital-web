import React from 'react'
import { TextField, Button, Stack } from "@mui/material";
import Container from '@mui/material/Container';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { NavLink, useNavigate } from "react-router-dom";
import { login } from '../../api/auth/login-api';
import { useDispatch } from 'react-redux';
import { loginAction } from '../../rtk-query/auth-reducer';

const schema = yup
    .object()
    .shape({
        nickname: yup.string().required(),
        password: yup.string().min(8).required(),
    })
    .required();
export default function Login() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { register, handleSubmit, formState: { errors } } = useForm({
        resolver: yupResolver(schema),
    });
    const onSubmit = async data => {
        const token = await login(data);
        const nickname = data.nickname;
        dispatch(loginAction({nickname,token}))
        return (
            navigate('/todo')
        )
    }
    return (
        <Container sx={{ width: "350px" }} >
            <Stack spacing={2} margin={5}>
                <TextField error={!!errors.nickname?.message} helperText={errors.nickname?.message} {...register("nickname", { required: true })} label="Nickname" variant="standard" />
                <TextField error={!!errors.password?.message} helperText={errors.password?.message} {...register("password", { required: true })} label="Password" variant="standard" />
                <Button onClick={handleSubmit(onSubmit)} variant="contained">Login</Button>
                <Button variant="text"><NavLink to='/' style={isActive => ({
                    color: isActive ? "green" : "blue"
                })}>Register</NavLink>
                </Button>
            </Stack>
        </Container>

    )
}
