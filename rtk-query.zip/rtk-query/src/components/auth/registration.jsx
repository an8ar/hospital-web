import React from "react";
import { TextField, Button, Stack } from "@mui/material";
import { useForm, } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { NavLink, useNavigate } from "react-router-dom";
import {registerUser} from "../../api/auth/register-api";
import Container from '@mui/material/Container';
import { useDispatch } from 'react-redux';
import { registerAction } from '../../rtk-query/auth-reducer';

const schema = yup
    .object()
    .shape({
        nickname: yup.string().required(),
        password: yup.string().min(8).required(),
    })
    .required();
function Register() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { register, handleSubmit, formState: { errors } } = useForm({
        resolver: yupResolver(schema),
    });
    const onSubmit = async data => {
        const token = await registerUser(data);
        const nickname = data.nickname;
        dispatch(registerAction({nickname,token}));
        return (
            navigate('/todo')
        )
    }

    return (
        <Container sx={{ width: "350px" }}>
            <Stack spacing={2} margin={5}>
                <TextField error={!!errors.nickname?.message} helperText={errors.username?.message} {...register("nickname", { required: true })} label="Nickname" variant="standard" />
                <TextField error={!!errors.password?.message} helperText={errors.password?.message} {...register("password", { required: true })} label="Password" variant="standard" />
                <Button onClick={handleSubmit((onSubmit))} variant='contained'>
                    Register
                </Button>
                <Button>
                    <NavLink to='/login' style={isActive => ({
                        color: isActive ? "green" : "blue"
                    })}   >Login
                    </NavLink>
                </Button>
            </Stack>
        </Container>
    );

}


export default Register;