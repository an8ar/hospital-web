import { getAll } from '../api/todo/get-all';
import { deleteItem } from '../api/todo/delete'
import { deleteAllTasks } from '../api/todo/delete-all'
import { addTaskTodo } from '../api/todo/add-task';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { setTodoAction,addTodoAction, deleteTodoAction, deleteAllTasksAction, deleteSelectedAction } from '../store/todo-slice';

export const useTodo = () => {
    const dispatch = useDispatch();
    const todoTask = useSelector(state => state.todo.todo);

    useEffect(() => {
        getTasks();
    }, [])
    async function getTasks() {
        const responce = await getAll();
        dispatch(setTodoAction(responce));
    }
    async function deleteTask(itemDelete) {
        await deleteItem(itemDelete);
        dispatch(deleteTodoAction(itemDelete));
    }

    async function addTodo(item) {
        const responce = await addTaskTodo(item);
        dispatch(addTodoAction(responce.data));
    }

    function deleteSelected() {
        todoTask.map(async (task) => {
            if (task.completed == true) {
                await deleteTask(task);
            }
        })
        dispatch(deleteSelectedAction());
    }
    async function deleteAll() {
        await deleteAllTasks(todoTask);
        dispatch(deleteAllTasksAction());

    }

    return { todoTask, deleteAll, addTodo, deleteSelected, deleteTask, getTasks };
}