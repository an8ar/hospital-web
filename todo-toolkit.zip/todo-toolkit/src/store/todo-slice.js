import { createSlice } from '@reduxjs/toolkit'

const todoSlice = createSlice({
    name: 'todo',
    initialState: {
        todo: []
    },
    reducers: {
        setTodoAction(state, action){
            state.todo = action.payload;
        },
        addTodoAction(state, action) {
            state.todo.push(action.payload)
        },
        deleteTodoAction(state, action) {
            state.todo = state.todo.filter((todo) => todo.id !== action.payload.id);
        },
        deleteAllTasksAction(state, action) {
            state.todo = [];
        },
        deleteSelectedAction(state, action) {
            state.todo.filter((todo) => !todo.completed)
        },
        selectTodoAction(state, action){
            state.todo.map(function (item){
                if(item.id === action.payload.id){
                    item.completed = !item.completed;
                }
            })
        }
    }
})

export const { selectTodoAction,setTodoAction,addTodoAction, deleteTodoAction, deleteAllTasksAction, deleteSelectedAction} = todoSlice.actions;

export const todoReducer = todoSlice.reducer;