import { createSlice } from '@reduxjs/toolkit'

const authSlice = createSlice({
    name: 'auth',
    initialState: {
        auth: ''
    },
    reducers: {
        logoutAction(state, action){
            state.auth = '';
        },
        loginAction(state, action){
            console.log(action);
            state.auth = action.payload.nickname;
        },
        registerAction(state, action){
            state.auth = action.payload.nickname;
        },
        setUserAction(state,action){
            state.auth = action.payload.nickname;
        }
    }
})

export const { setUserAction,logoutAction,loginAction, registerAction} = authSlice.actions;

export const authReducer = authSlice.reducer;