import { configureStore } from "@reduxjs/toolkit";
import {todoReducer} from './todo-slice';
import { authReducer } from "./auth-reducer";
export const store =  configureStore({
    reducer: {
        todo: todoReducer,
        auth: authReducer
    }
})