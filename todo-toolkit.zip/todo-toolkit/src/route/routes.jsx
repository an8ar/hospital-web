import React from 'react'
import Todo from '../components/todo/index';
import Register from '../components/auth/registration';
import Login from '../components/auth/login';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import NavBarApp from '../components/layouts/navbar.jsx';

function RouterApp() {

    return (
        <BrowserRouter>
            <NavBarApp classname="navbarr"></NavBarApp>
            <Routes>
                <Route path='/login' element={<Login />} />
                <Route path='/todo' element={<Todo />} />
                <Route path='/' element={<Register />} />
            </Routes>
        </BrowserRouter>
    );
}

export default RouterApp;
