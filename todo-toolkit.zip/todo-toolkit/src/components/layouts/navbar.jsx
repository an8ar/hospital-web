import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useNavigate } from "react-router-dom";
import { useSnackbar } from 'notistack';
import { useDispatch, useSelector } from 'react-redux';
import { logoutAction } from '../../store/auth-reducer';
import { useEffect } from 'react';
import { getUser } from '../../api/auth/get-user';
import { setUserAction } from '../../store/auth-reducer';

export default function NavBarApp() {
  const dispatch = useDispatch();
  useEffect(() => {
    async function gettingUser() {
      const user = await getUser();
      dispatch(setUserAction(user));
    }
    gettingUser();
  }, [])

  const username = useSelector((state) => state.auth.auth);

  const navigate = useNavigate();
  
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();

  function navigating() {
    dispatch(logoutAction());
    if (localStorage.getItem('token') == null) {
      enqueueSnackbar("You are already logged out stupid son of the bitch!!!", { variant: 'warning' });
    }
    localStorage.removeItem('token')
    navigate('/login');
  }


  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Todo List of {username}
          </Typography>
          <Button color="inherit" onClick={navigating
          }>Logout</Button>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
