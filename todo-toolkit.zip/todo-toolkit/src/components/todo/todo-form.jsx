import React from 'react';
import { useState } from 'react';
import { TextField, Button } from '@mui/material';
import Divider from '@mui/material/Divider';
import Stack from '@mui/material/Stack';

const TodoForm = (props) => {

    const [value, setvalue] = useState('');

    function addTodo() {
        if (value !== undefined) {
            props.addTask(value);
        }
        setvalue('');
    }

    return (
        <Stack spacing={3} direction="row" divider={<Divider orientation="vertical" flexItem />} >
            <TextField id="outlined-basic" label="Enter new Task" variant="outlined" value={value} onChange={((e) => setvalue(e.target.value))} />
            <Button variant="contained" onClick={addTodo} size="large" className='buttonAdd'>ADD TASK</Button>
        </Stack>

    );
}

export default TodoForm;