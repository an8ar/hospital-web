import React from "react";
import DeleteIcon from '@mui/icons-material/Delete';
import { Button } from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Checkbox from '@mui/material/Checkbox';
import IconButton from '@mui/material/IconButton';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import {selectTodoAction} from '../../store/todo-slice';
import { useDispatch, useSelector } from 'react-redux';

function Tasks(props) {
    const array = props.array;
    const dispatch  = useDispatch();
    if (array.length == 0) {
        return (
            <Alert severity="info">There is no tasks!</Alert>
        )
    }
    function selectTodo(task){
        dispatch(selectTodoAction(task))
    }
    return <Stack >
        <List sx={{ width: '100%', maxWidth: 400 }}>
            {array.map(task =>
                <ListItem
                    key={task.id}
                    divider
                    secondaryAction={
                        <IconButton edge="end" aria-label="comments" onClick={() => props.deleteTask(task)}>
                            <DeleteIcon />
                        </IconButton>
                    }
                    disablePadding
                >
                    <ListItemButton>
                        <ListItemIcon>
                            <Checkbox type="checkbox" className="t" onChange={()=>selectTodo(task)
                            } />
                        </ListItemIcon>
                        <ListItemText sx={{overflow: "scroll" }} >{task.title}</ListItemText>
                    </ListItemButton>
                </ListItem>

            )}
        </List>

        <Stack direction="row" spacing={2}>
            <Button variant="contained" onClick={() => props.deleteSelected()}>Delete Selected</Button>
            <Button variant="contained" onClick={() => props.deleteAll()}>Delete All</Button>
        </Stack>
    </Stack>
}
export default Tasks;