import React from 'react'
import TodoForm from './todo-form';
import Tasks from './tasks';
import Stack from '@mui/material/Stack';
import Container from '@mui/material/Container';
import { useTodo } from '../../hooks/use-todo'
function Todo() {
  const data = useTodo();
  const { todoTask, deleteAll, addTodo, deleteSelected, deleteTask } = data
  return (
    <Container >
      <Stack direction="column"
        justifyContent="center"
        alignItems="center"
        spacing={2}
        margin={5}>
        <TodoForm addTask={addTodo} />
        <Tasks className="listOfTodos" array={todoTask} deleteTask={deleteTask} deleteSelected={deleteSelected} deleteAll={deleteAll} />
      </Stack>
    </Container>
  );
};

export default Todo;