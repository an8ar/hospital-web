import axios from 'axios';
export async function deleteAllTasks(array){
    array.map(async (task) => {
        await axios.delete(`http://127.0.0.1:8000/todo/${task.id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem(
              "token"
            )}`,
          }
        });
      })


}