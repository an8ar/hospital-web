import axios from 'axios';
export  async function  getAll(){
    const responce =  await axios.get('http://127.0.0.1:8000/todo', {
        headers: {
          Authorization: `Bearer ${localStorage.getItem(
            "token"
          )}`,
        }
      })
      return responce.data;
}