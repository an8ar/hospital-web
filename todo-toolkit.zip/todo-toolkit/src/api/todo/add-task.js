import axios from 'axios'
export async function addTaskTodo(item){
    const responce = await axios.post('http://127.0.0.1:8000/todo', {
        title: item,
      }, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem(
            "token"
          )}`,
        }
      })
    return responce;
}