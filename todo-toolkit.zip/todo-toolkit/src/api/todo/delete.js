import axios from 'axios';
export  async function  deleteItem(itemDelete){
    await axios.delete(`http://127.0.0.1:8000/todo/${itemDelete.id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem(
            "token"
          )}`,
        }
      });
}