import axios from 'axios';

export async function registerUser(data) {
        const responce = await axios.post('http://127.0.0.1:8000/user/registration', {
                nickname: data.nickname,
                password: data.password
        })
        localStorage.setItem("token", responce.data.token);
        return responce;

}


