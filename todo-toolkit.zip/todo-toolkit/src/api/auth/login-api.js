import axios from 'axios';

export async function login(data) {
    try {
        const responce = await axios.post('http://127.0.0.1:8000/user/login', {
            nickname: data.nickname,
            password: data.password
            }
        ) 
        localStorage.setItem("token", responce.data.token);
        return responce;
    }catch (error) {
        console.log("Error in a login_api", error);
    }
}





