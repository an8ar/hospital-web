import axios from 'axios';

export async function getUser() {
    if (!!localStorage.getItem('token')) {
        const user = await axios.get('http://127.0.0.1:8000/user/check', {
            headers: {
                Authorization: `Bearer ${localStorage.getItem(
                    "token"
                )}`,
            }
        })
        return user.data;
    } else {
        return "no one";
    }
}